﻿using MPI; // Не забудь добавить ссылку на библиотеку через NuGet
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Text.Json.Serialization;


namespace VKR_MPI_V1
{
    class Program
    {
        static void Main(string[] args)
        {
            using (new MPI.Environment(ref args))
            {

                var comm = Communicator.world;

                var config = LoadConfig();
                List<string> files = new List<string>();


                // 1. Только Master (Rank 0) сканирует директорию
                if (comm.Rank == 0)
                {

                    
                    Console.WriteLine($" {config.Pattern}");
                    files = GetFilesSafe(config.FilePath);
                    Console.WriteLine($"[MASTER]: Найдено файлов: {files.Count}");
                }
                
                // 2. Рассылаем список файлов всем процессам
                comm.Broadcast(ref files, 0);

                long localMatches = 0;
                Console.WriteLine($"[MASTER]: Найдено файлов:");
                // 3. Каждый процесс обрабатывает только "свои" файлы
                for (int i = 0; i < files.Count; i++)
                {
                    if (i % comm.Size == comm.Rank)
                    {
                        // Передаем конкретный файл в ProcessFile
                        localMatches += Pipeline.Consumer.ProcessFile(files[i], config);
                    }
                }

                // 4. Собираем результаты со всех узлов
                long globalTotal = comm.Reduce(localMatches, Operation<long>.Add, 0);

                if (comm.Rank == 0)
                {
                    Console.WriteLine($"Total matches: {globalTotal}");
                }
                

            }
        }

        public static AppConfig LoadConfig(string path = "appconfig.json")
        {
            try
            {
                // 1. Приводим путь к абсолютному
                if (!Path.IsPathRooted(path))
                {
                    string baseDir = AppContext.BaseDirectory;
                    path = Path.Combine(baseDir, path);
                }

                Console.WriteLine($"[CONFIG] Loading config from: {path}");

                // 2. Проверка существования файла
                if (!File.Exists(path))
                {
                    Console.WriteLine($"[CONFIG][ERROR] File not found: {path}");
                    throw new FileNotFoundException($"Config file not found: {path}");
                }

                // 3. Читаем файл
                string json = File.ReadAllText(path);

                if (string.IsNullOrWhiteSpace(json))
                {
                    Console.WriteLine("[CONFIG][ERROR] Config file is empty");
                    throw new Exception("Config file is empty");
                }

                Console.WriteLine("[CONFIG] Raw JSON:");
                Console.WriteLine(json);

                // 4. Десериализация
                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };

                AppConfig? config = JsonSerializer.Deserialize<AppConfig>(json, options);

                if (config == null)
                {
                    Console.WriteLine("[CONFIG][ERROR] Deserialization returned null");
                    throw new Exception("Failed to deserialize config");
                }

                // 5. Валидация ключевых полей
                ValidateConfig(config);

                Console.WriteLine("[CONFIG] Config loaded successfully");

                return config;
            }
            catch (JsonException ex)
            {
                Console.WriteLine("[CONFIG][ERROR] JSON parsing error:");
                Console.WriteLine(ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                
                throw;
            }
        }

        private static void ValidateConfig(AppConfig config)
        {
            if (string.IsNullOrWhiteSpace(config.FilePath))
                throw new Exception("FilePath is empty");

            if (string.IsNullOrWhiteSpace(config.Pattern))
                throw new Exception("Pattern is empty");

            if (config.ChunkSizeMB <= 0)
                throw new Exception("ChunkSizeMB must be > 0");

            if (config.OverlapKB < 0)
                throw new Exception("OverlapKB must be >= 0");

            if (config.WorkerThreads <= 0)
                throw new Exception("WorkerThreads must be > 0");

            Console.WriteLine($"[CONFIG] FilePath: {config.FilePath}");
            Console.WriteLine($"[CONFIG] Pattern: {config.Pattern}");
            Console.WriteLine($"[CONFIG] ChunkSizeMB: {config.ChunkSizeMB}");
            Console.WriteLine($"[CONFIG] OverlapKB: {config.OverlapKB}");
            Console.WriteLine($"[CONFIG] WorkerThreads: {config.WorkerThreads}");
        }
        /*
        static AppConfig LoadConfig(string path = "D:\\programki\\VKR_MPI_V1\\bin\\Debug\\net8.0\\appconfig.json")
        {
            if (!Path.IsPathRooted(path))
                path = Path.Combine(AppContext.BaseDirectory, path);

            if (!File.Exists(path))
            {
                Console.WriteLine($" file netu");
                throw new FileNotFoundException($"Config file not found: {path}");
            }

            string json = File.ReadAllText(path);

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            AppConfig? config = JsonSerializer.Deserialize<AppConfig>(json, options);

            if (config == null)
            {
                Console.WriteLine($" config netu");
                throw new InvalidOperationException("Failed to deserialize appconfig.json");
            }
                

            return config;
        }
        */
        static List<string> GetFilesSafe(string path)
        {
            var result = new List<string>();
            try
            {
                // Проверяем, если указан конкретный файл, а не папка
                if (File.Exists(path))
                {
                    result.Add(path);
                    return result;
                }
                
                result.AddRange(Directory.GetFiles(path));
                foreach (var dir in Directory.GetDirectories(path))
                {
                    result.AddRange(GetFilesSafe(dir));
                }
            }
            catch (Exception) { Console.WriteLine("Error getting files"); }
            return result;
        }
    
    }
}